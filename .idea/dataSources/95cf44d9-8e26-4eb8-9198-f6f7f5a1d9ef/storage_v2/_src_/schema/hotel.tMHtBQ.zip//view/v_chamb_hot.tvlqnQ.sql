create view v_chamb_hot as
select `hotel`.`chambre`.`cha_numero` AS `numero chambre`, `hotel`.`hotel`.`hot_nom` AS `nom hotel`
from `hotel`.`chambre`
         join `hotel`.`hotel`
where `hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`;

