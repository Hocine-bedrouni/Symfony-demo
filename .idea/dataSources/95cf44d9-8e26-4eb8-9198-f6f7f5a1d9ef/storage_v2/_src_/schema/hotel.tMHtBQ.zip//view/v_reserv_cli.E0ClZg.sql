create view v_reserv_cli as
select `hotel`.`reservation`.`res_id` AS `num reservation`, `hotel`.`client`.`cli_nom` AS `nom client`
from `hotel`.`reservation`
         join `hotel`.`client`
where `hotel`.`reservation`.`res_cli_id` = `hotel`.`client`.`cli_id`;

