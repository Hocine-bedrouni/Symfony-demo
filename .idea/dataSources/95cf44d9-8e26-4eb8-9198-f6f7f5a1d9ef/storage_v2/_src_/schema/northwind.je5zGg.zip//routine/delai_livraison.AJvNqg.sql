create
    definer = root@localhost procedure delai_livraison(IN datelivraison date, IN datecommande date)
BEGIN
SELECT floor(avg(DATEDIFF(datelivraison, datecommande)))
from orders;
END;

