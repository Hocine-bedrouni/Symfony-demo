create
    definer = root@localhost procedure date_derniere_commande(IN entreprise varchar(50))
BEGIN
SELECT MAX(orderdate) FROM orders 
JOIN customers 
ON orders.customerid = customers.customerid 
WHERE companyname = entreprise;
END;

